﻿namespace BankOffice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnStart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ListBoxLog = new System.Windows.Forms.ListBox();
            this.lblQueueLength = new System.Windows.Forms.Label();
            this.lblCashier1 = new System.Windows.Forms.Label();
            this.lblCashier2 = new System.Windows.Forms.Label();
            this.lblCashier3 = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStart.Location = new System.Drawing.Point(65, 102);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(90, 40);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 600;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ListBoxLog
            // 
            this.ListBoxLog.FormattingEnabled = true;
            this.ListBoxLog.ItemHeight = 16;
            this.ListBoxLog.Location = new System.Drawing.Point(426, 67);
            this.ListBoxLog.Name = "ListBoxLog";
            this.ListBoxLog.Size = new System.Drawing.Size(362, 260);
            this.ListBoxLog.TabIndex = 2;
            // 
            // lblQueueLength
            // 
            this.lblQueueLength.AutoSize = true;
            this.lblQueueLength.Location = new System.Drawing.Point(45, 187);
            this.lblQueueLength.Name = "lblQueueLength";
            this.lblQueueLength.Size = new System.Drawing.Size(67, 16);
            this.lblQueueLength.TabIndex = 3;
            this.lblQueueLength.Text = "Очередь:";
            // 
            // lblCashier1
            // 
            this.lblCashier1.AutoSize = true;
            this.lblCashier1.Location = new System.Drawing.Point(150, 229);
            this.lblCashier1.Name = "lblCashier1";
            this.lblCashier1.Size = new System.Drawing.Size(36, 16);
            this.lblCashier1.TabIndex = 4;
            this.lblCashier1.Text = "state";
            // 
            // lblCashier2
            // 
            this.lblCashier2.AutoSize = true;
            this.lblCashier2.Location = new System.Drawing.Point(150, 272);
            this.lblCashier2.Name = "lblCashier2";
            this.lblCashier2.Size = new System.Drawing.Size(36, 16);
            this.lblCashier2.TabIndex = 5;
            this.lblCashier2.Text = "state";
            // 
            // lblCashier3
            // 
            this.lblCashier3.AutoSize = true;
            this.lblCashier3.Location = new System.Drawing.Point(150, 311);
            this.lblCashier3.Name = "lblCashier3";
            this.lblCashier3.Size = new System.Drawing.Size(36, 16);
            this.lblCashier3.TabIndex = 6;
            this.lblCashier3.Text = "state";
            // 
            // btnStop
            // 
            this.btnStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStop.Location = new System.Drawing.Point(213, 102);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(88, 40);
            this.btnStop.TabIndex = 7;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Кассир 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 272);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Кассир 2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Кассир 3:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.lblCashier3);
            this.Controls.Add(this.lblCashier2);
            this.Controls.Add(this.lblCashier1);
            this.Controls.Add(this.lblQueueLength);
            this.Controls.Add(this.ListBoxLog);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ListBox ListBoxLog;
        private System.Windows.Forms.Label lblQueueLength;
        private System.Windows.Forms.Label lblCashier1;
        private System.Windows.Forms.Label lblCashier2;
        private System.Windows.Forms.Label lblCashier3;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

