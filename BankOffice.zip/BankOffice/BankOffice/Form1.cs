﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankOffice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeCashiers();
            ListLog = ListBoxLog;
        }

        private void InitializeCashiers()
        {
            for (int i = 0; i < 3; i++) // Зададим 3 кассиров
            {
                cashiers.Add(new Cashier());
            }
        }

        ListBox ListLog;
        private Random random = new Random();
        private Queue<Client> queue = new Queue<Client>();
        private List<Cashier> cashiers = new List<Cashier>();
        private int clientCounter = 0;

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        public class Client
        {
            public int Id { get; set; }
        }

        public class Cashier
        {
            private static Random random = new Random();
            private int serviceTime;
            private int timeLeft;
            public Client CurrentClient { get; private set; }
            public bool IsAvailable => timeLeft <= 0;

            public void StartServing(Client client)
            {
                CurrentClient = client;
                serviceTime = random.Next(5, 15); // Время обслуживания клиента (например, от 5 до 15 тиков)
                timeLeft = serviceTime;
            }

            public void Update()
            {
                if (!IsAvailable)
                {
                    timeLeft--;
                    if (timeLeft <= 0)
                    {
                        CurrentClient = null;
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            GenerateClientArrival();
            ProcessCashiers();
            UpdateUI();
        }

        private void GenerateClientArrival()
        {
            // Вероятность прихода клиента в каждом тике
            if (random.NextDouble() < 0.3)
            {
                var client = new Client { Id = ++clientCounter };
                queue.Enqueue(client);
                ListLog.Items.Add($"Клиент {client.Id} прибыл.");
            }
        }

        private void ProcessCashiers()
        {
            foreach (var cashier in cashiers)
            {
                if (cashier.IsAvailable && queue.Count > 0)
                {
                    var client = queue.Dequeue();
                    cashier.StartServing(client);
                    ListLog.Items.Add($"Клиент {client.Id} обслуживается кассиром {cashiers.IndexOf(cashier) + 1}.");
                }
                cashier.Update();
            }
        }

        private void UpdateUI()
        {
            lblQueueLength.Text = "Очередь: " + queue.Count.ToString();
            // Обновление интерфейса для каждого кассира
            for (int i = 0; i < cashiers.Count; i++)
            {
                var cashierLabel = Controls.Find($"lblCashier{i + 1}", true)[0] as Label;
                cashierLabel.Text = cashiers[i].IsAvailable ? "Свободен" : $"Обслуживает {cashiers[i].CurrentClient.Id}";
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}
