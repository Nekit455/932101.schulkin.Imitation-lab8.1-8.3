﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankOffice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeCashiers();
            ListLog = ListBoxLog;
        }

        private void InitializeCashiers()
        {
            for (int i = 0; i < 3; i++) // Зададим 3 кассиров
            {
                cashiers.Add(new Cashier());
            }
        }

        ListBox ListLog;
        Random random = new Random();
        PriorityQueue<Event> eventQueue = new PriorityQueue<Event>();
        Queue<Client> clientQueue = new Queue<Client>();
        List<Cashier> cashiers = new List<Cashier>();
        int clientCounter = 0;
        int currentTime = 0;

        private void btnStart_Click(object sender, EventArgs e)
        {
            clientQueue.Clear();
            clientCounter = 0;
            currentTime = 0;
            ListBoxLog.Items.Clear();
            ScheduleNextClientArrival();
            timer1.Start();
        }

        public class Client
        {
            public int Id { get; set; }
        }

        public class Cashier
        {
            public bool IsAvailable { get; set; } = true;
            public Client CurrentClient { get; set; }
        }

        public enum EventType
        {
            ClientArrival,
            ServiceCompletion
        }

        public class Event : IComparable<Event>
        {
            public int Time { get; }
            public EventType Type { get; }
            public Cashier Cashier { get; }
            public Client Client { get; }

            public Event(int time, EventType type, Cashier cashier = null, Client client = null)
            {
                Time = time;
                Type = type;
                Cashier = cashier;
                Client = client;
            }

            public int CompareTo(Event other)
            {
                return Time.CompareTo(other.Time);
            }
        }

        public class PriorityQueue<T> where T : IComparable<T>
        {
            private List<T> data;

            public PriorityQueue()
            {
                data = new List<T>();
            }

            public void Enqueue(T item)
            {
                data.Add(item);
                data.Sort();
            }

            public T Dequeue()
            {
                if (data.Count == 0)
                    throw new InvalidOperationException("Queue is empty");

                T item = data[0];
                data.RemoveAt(0);
                return item;
            }

            public int Count => data.Count;
        }
    

        private void timer1_Tick(object sender, EventArgs e)
        {            
            Event nextEvent = eventQueue.Dequeue();
            currentTime = nextEvent.Time;

            switch (nextEvent.Type)
            {
                case EventType.ClientArrival:
                    ProcessClientArrival();
                    break;
                case EventType.ServiceCompletion:
                    ProcessServiceCompletion(nextEvent.Cashier, nextEvent.Client);
                    break;
            }
            UpdateUI();
        }

        private void ScheduleNextClientArrival()
        {
            int arrivalTime = currentTime + random.Next(1, 5); // Клиенты прибывают случайно через 1-5 единиц времени
            eventQueue.Enqueue(new Event(arrivalTime, EventType.ClientArrival));
        }

        private void ScheduleServiceCompletion(Cashier cashier, Client client)
        {
            int serviceTime = random.Next(5, 15); // Время обслуживания клиента (например, от 5 до 15 единиц времени)
            eventQueue.Enqueue(new Event(currentTime + serviceTime, EventType.ServiceCompletion, cashier, client));
        }

        private void ProcessClientArrival()
        {
            clientCounter++;
            var client = new Client { Id = clientCounter };
            clientQueue.Enqueue(client);
            ListLog.Items.Add($"Клиент {client.Id} прибыл.");

            ScheduleNextClientArrival();
            AssignClientToCashier();
        }

        private void ProcessServiceCompletion(Cashier cashier, Client client)
        {
            cashier.IsAvailable = true;
            ListLog.Items.Add($"Клиент {client.Id} обслужен кассиром {cashiers.IndexOf(cashier) + 1}.");
            AssignClientToCashier();
        }

        private void AssignClientToCashier()
        {
            foreach (var cashier in cashiers)
            {
                if (cashier.IsAvailable && clientQueue.Count > 0)
                {
                    var client = clientQueue.Dequeue();
                    cashier.IsAvailable = false;
                    cashier.CurrentClient = client;
                    ListLog.Items.Add($"Клиент {client.Id} обслуживается кассиром {cashiers.IndexOf(cashier) + 1}.");
                    ScheduleServiceCompletion(cashier, client);
                }
            }
        }

        private void UpdateUI()
        {
            lblQueueLength.Text = "Очередь: " + clientQueue.Count + " чел.";
            
            // Обновление состояния кассиров
            for (int i = 0; i < cashiers.Count; i++)
            {
                var cashierLabel = Controls.Find($"lblCashier{i + 1}", true)[0] as Label;
                cashierLabel.Text = cashiers[i].IsAvailable ? "Свободен" : $"Обслуживает {cashiers[i].CurrentClient.Id}";
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}
