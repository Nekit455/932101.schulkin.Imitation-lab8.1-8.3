﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ДСВ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeValues();
        }

        NumericUpDown nm1, nm2, nm3, nm4, nm5;

        static double a, b, c, d, f;

        public void InitializeValues()
        {
            nm1 = num1;
            nm2 = num2;
            nm3 = num3;
            nm4 = num4;
            nm5 = num5;
        }

        Random rnd = new Random();
        //private List<double> Probs = new List<double> ();
        private void button2_Click(object sender, EventArgs e)
        {
            a = (double)nm1.Value;
            b = (double)nm2.Value;
            c = (double)nm3.Value;
            d = (double)nm4.Value;
            f = 1 - a - b - c - d;
            nm5.Value = 1 - nm1.Value - nm2.Value - nm3.Value - nm4.Value;

            if (nm1.Value + nm2.Value + nm3.Value + nm4.Value >= 1)
            {
                label9.Text = "Error";
            }
            else
            {           
                int N = (int)numSeries.Value;
                double catA = 0, catB = 0, catC = 0, catD = 0, catE = 0;

                for (int i = 0; i < (int)numSeries.Value; i++)
                {
                    double randomNum = rnd.NextDouble();     
                  
                    if (randomNum < a) 
                    { 
                        catA++;
                    }
                    if (randomNum < b)
                    {
                        catB++;
                    }
                    if (randomNum < c)
                    {
                        catC++;
                    }
                    if (randomNum < d)
                    {
                        catD++;
                    }
                    if (randomNum < f)
                    {
                        catE++;
                    }
                }
                chart1.Series[0].Points.Clear();
                chart1.Series[0].Points.AddXY("0", catA / N);
                chart1.Series[0].Points.AddXY("1", catB / N);
                chart1.Series[0].Points.AddXY("2", catC / N);
                chart1.Series[0].Points.AddXY("3", catD / N);
                chart1.Series[0].Points.AddXY("4", catE / N);

                double mean = 0, th_mean = 0;
                double var = 0, th_var = 0;
                double[] A = new double[5];
                double[] probs = new double[5];
                A[0] = catA; A[1] = catB; A[2] = catC; A[3] = catD; A[4] = catE;
                probs[0] = a; probs[1] = b; probs[2] = c; probs[3] = d; probs[4] = f;
                
                for (int i = 0; i < 4; i++) {
                    mean += (A[i] / N) * i;
                    th_mean += probs[i] * i;
                }
                for (int i = 0; i < 4; i++) {
                    var += (A[i] / N) * i * i; 
                    th_var = probs[i] * i * i;
                }
                var -= mean * mean;
                lblMean.Text = mean.ToString();
                lblVar.Text = Math.Round(var, 2).ToString();

                double errM, errV;

                double deltaM = Math.Abs(mean - th_mean);
                double deltaV = Math.Abs(var - th_var);
                errM = deltaM / th_mean;
                errV = deltaV / th_var;

                string srtM = "(err = " + Math.Round(errM, 2).ToString() + " %)";
                string srtV = "(err = " + Math.Round(errV, 2).ToString() + " %)";
                lblerrM.Text = srtM;
                lblerrV.Text = srtV;

                double chi2 = 0;
                for (int i = 0; i < 4; i++)                
                    chi2 += (A[i] * A[i]) / N / probs[i];
                chi2 -= N;

                if (chi2 > 9.488)
                {
                    lblChi2.Text = Math.Round(chi2, 3) + " > 9.488, плохо!";
                }
                else
                {
                    lblChi2.Text = Math.Round(chi2, 3) + " <= 9.488, хорошо!";
                }
            }
        }
    }
}
