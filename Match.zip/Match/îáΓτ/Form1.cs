﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Матч
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random rnd = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            double lam1 = (double)num1.Value;
            double lam2 = (double)num2.Value;

            double a1, a2;
            double sum1 = 0, sum2 = 0;
            int check1 = 0, check2 = 0;

            while (sum1 >= -lam1 || sum2 >= -lam2)
            {
                a1 = rnd.NextDouble();
                a2 = rnd.NextDouble();
                
                if (sum1 >= -lam1)
                {
                    sum1 += Math.Log(a1);
                    check1++;
                }

                if (sum2 >= -lam2)
                {
                    sum2 += Math.Log(a2);
                    check2++;
                }
            }

            lblRes.Text = check1 + " : " + check2;
            lblWin1.Visible = false;
            lblWin2.Visible = false;
            lblNot.Visible = false;

            if (check1 > check2) lblWin1.Visible = true;    
            if (check1 < check2) lblWin2.Visible = true;
            if (check1 == check2)lblNot.Visible = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
