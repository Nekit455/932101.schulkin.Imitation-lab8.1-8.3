﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicBall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<(string answer, int weight)> answers = new List<(string, int)> 
        {
            ("Бесспорно", 1),   
            ("Без сомнения", 2),
            ("Определенно да", 3),          
            ("Знаки говорят — да", 4),       
            ("Спроси позже", 5),                     
            ("Не рассчитывай на это", 6),
            ("Мой ответ — нет", 7),                   
            ("Весьма сомнительно", 8)
        };

        Random rnd = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = GetRandomAnswer();
        }

        private string GetRandomAnswer()
        {
            // Суммируем веса всех ответов
            int totalWeight = 0;
            foreach (var (_, weight) in answers)
            {
                totalWeight += weight;
            }

            // Генерируем случайное число от 0 до суммы весов
            int randomNumber = rnd.Next(totalWeight);

            // Выбираем ответ, учитывая его вероятность (вес)
            foreach (var (answer, weight) in answers)
            {
                if (randomNumber < weight)
                    return answer;
                randomNumber -= weight;
            }

            // Вернем последний ответ, если что-то пошло не так
            return answers[answers.Count - 1].answer;
        }
    }
}
