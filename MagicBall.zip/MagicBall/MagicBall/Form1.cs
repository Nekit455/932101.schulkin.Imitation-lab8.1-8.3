﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicBall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeValues();
        }

        NumericUpDown nm1, nm2, nm3, nm4, nm5;

        static double a, b, c, d, f;

        public void InitializeValues()
        {
            nm1 = num1;
            nm2 = num2;
            nm3 = num3;
            nm4 = num4;  
            nm5 = num5;
        }
        
        private List<(string answer, double prob)> answers = new List<(string, double)> {};

        Random rnd = new Random();

        private void button2_Click(object sender, EventArgs e)
        {
            a = (double)nm1.Value;
            b = (double)nm2.Value;
            c = (double)nm3.Value;
            d = (double)nm4.Value;
            f = 1-a-b-c-d;
            nm5.Value = 1 - nm1.Value - nm2.Value - nm3.Value - nm4.Value;

            answers.Clear();
            answers.Add(("Бесспорно", a));
            answers.Add(("Знаки говорят — да", b));
            answers.Add(("Мой ответ — нет", c));
            answers.Add(("Весьма сомнительно", d));
            answers.Add(("Спроси позже", f));

            if (nm1.Value + nm2.Value + nm3.Value + nm4.Value >= 1)
            {
                label9.Text = "Error";               
            }
            else
            {
                int N = (int)numSeries.Value;
                double catA = 0, catB = 0, catC = 0, catD = 0, catE = 0;

                for (int i = 0; i < (int)numSeries.Value; i++)
                {                   
                    double randomNum = rnd.NextDouble();
                    if (randomNum < a) catA++;
                    if (randomNum < b) catB++;
                    if (randomNum < c) catC++;
                    if (randomNum < d) catD++;
                    if (randomNum < f) catE++;                    
                }
                chart1.Series[0].Points.Clear();
                chart1.Series[0].Points.AddXY("A", catA/N);
                chart1.Series[0].Points.AddXY("B", catB/N);
                chart1.Series[0].Points.AddXY("C", catC/N);
                chart1.Series[0].Points.AddXY("D", catD/N);
                chart1.Series[0].Points.AddXY("E", catE/N);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = GetRandomAnswer();
        }

        private string GetRandomAnswer()
        {
            // Генерируем случайное число от 0 до 0.9
            double randomNumber = rnd.NextDouble();
           
            // Выбираем ответ, учитывая его вероятность (вес)
            foreach (var (answer, prob) in answers)
            {
                if (randomNumber < prob)
                    return answer;
                randomNumber -= prob;
            }

            // Вернем последний ответ, если что-то пошло не так
            return "???";
        }      
    }
}
